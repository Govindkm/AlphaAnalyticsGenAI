from google.cloud import storage

def upload_to_gcs(bucket_name, source_file_name, destination_blob_name):
  """Uploads a file to the specified bucket in Google Cloud Storage.

  Args:
      bucket_name: The name of the bucket to upload the file to.
      source_file_name: The path to the file on your local machine.
      destination_blob_name: The name of the object (file) in the bucket.
  """

  # Create a Google Cloud Storage client
  client = storage.Client()

  # Get a reference to the bucket
  bucket = client.bucket(bucket_name)

  # Create a blob object representing the file to upload
  blob = bucket.blob(destination_blob_name)

  # Upload the file to the bucket
  blob.upload_from_filename(source_file_name)

  print(f"File {source_file_name} uploaded to {bucket_name}/{destination_blob_name}")

# Example usage (replace with your details)
# bucket_name = "your-bucket-name"
# source_file_name = "path/to/your/file.txt"
# destination_blob_name = "your_file_name_in_gcs.txt"  # Optional, use source_file_name if not specified

# upload_to_gcs(bucket_name, source_file_name, destination_blob_name)